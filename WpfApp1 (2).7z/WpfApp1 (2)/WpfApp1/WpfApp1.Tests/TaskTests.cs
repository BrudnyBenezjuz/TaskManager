﻿using System;
using System.IO;
using WpfApp1;
using Xunit;

namespace WpfApp1
{
    public class TaskTests
    {
        [Fact]
        public void AddTask_ShouldIncreaseCount()
        {
            // Arrange
            var page = new MenagerTask(null);
            int initialCount = page.Tasks.Count;

            // Act
            page.Tasks.Add(new TaskItem
            {
                Title = "Test zadania",
                Date = DateTime.Today,
                Description = "Opis testowy",
                ColorName = "Orange"
            });

            // Assert
            Assert.True(page.Tasks.Count > initialCount);
        }

        [Fact]
        public void DeleteTask_ShouldRemoveItem()
        {
            // Arrange
            var page = new MenagerTask(null);
            var task = new TaskItem
            {
                Title = "Do usunięcia",
                Date = DateTime.Today,
                ColorName = "Red"
            };

            page.Tasks.Add(task);
            int beforeCount = page.Tasks.Count;

            // Act
            page.Tasks.Remove(task);

            // Assert
            Assert.True(page.Tasks.Count < beforeCount);
        }

        [Fact]
        public void Task_ShouldSetDefaultColor_WhenInvalid()
        {
            // Arrange
            var task = new TaskItem
            {
                Title = "Zły kolor",
                Date = DateTime.Today,
                ColorName = "NieistniejącyKolor"
            };

            // Act
            task.UpdateColor();

            // Assert
            Assert.Equal(System.Windows.Media.Brushes.LightGray.Color, task.Color.Color);
        }

        [Fact]
        public void SaveAndLoad_ShouldPersistTasks()
        {
            // Arrange
            var page = new MenagerTask(null);
            page.Tasks.Clear();

            var task = new TaskItem
            {
                Title = "Trwałość danych",
                Date = DateTime.Now,
                Description = "Test zapisu i odczytu",
                ColorName = "Yellow"
            };

            page.Tasks.Add(task);
            page.SaveTasks();

            // Act
            var page2 = new MenagerTask(null);
            page2.LoadTasks();

            // Assert
            Assert.Contains(page2.Tasks, t => t.Title == "Trwałość danych");
        }
    }
}
