﻿using Newtonsoft.Json;
using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace WpfApp1
{
    public partial class MenagerTask : Page
    {
        private Frame _mainFrame;
        private string _saveFilePath = "tasks.json";
        private int _deletedCount = 0;

        public ObservableCollection<TaskItem> Tasks { get; set; }

        public MenagerTask(Frame mainFrame)
        {
            InitializeComponent();
            _mainFrame = mainFrame;

            Tasks = new ObservableCollection<TaskItem>();
            TaskListPanel.ItemsSource = Tasks;

            LoadTasks();

            this.Unloaded += (s, e) => SaveTasks();
        }

        private void Settings_Click(object sender, RoutedEventArgs e)
        {
            SaveTasks();
            _mainFrame.Navigate(new Settings(_mainFrame));
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            SaveTasks();
            _mainFrame.Navigate(new Logowanie(_mainFrame));
        }

        private void AddTask_Click(object sender, RoutedEventArgs e)
        {
            string title = TaskTitleBox.Text.Trim();
            string description = TaskDescriptionBox.Text.Trim();
            DateTime? date = TaskDatePicker.SelectedDate;

            if (string.IsNullOrWhiteSpace(title) || date == null)
            {
                MessageBox.Show("Wprowadź tytuł i datę zadania!", "Błąd", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var colorItem = TaskColorBox.SelectedItem as ComboBoxItem;
            string colorName = colorItem?.Tag?.ToString() ?? "LightGray";

            var newTask = new TaskItem
            {
                Title = title,
                Date = date.Value,
                Description = description,
                ColorName = colorName
            };
            newTask.UpdateColor();

            Tasks.Add(newTask);
            SaveTasks();

            TaskTitleBox.Text = "";
            TaskDescriptionBox.Text = "";
            TaskDatePicker.SelectedDate = null;
            TaskColorBox.SelectedIndex = 0;

            CheckTaskMilestones();
        }

        private void CheckTaskMilestones()
        {
            int count = Tasks.Count;
            if (count == 5 || count == 10 || count == 15 || count == 20)
            {
                MessageBox.Show($"🎉 Udało się! Stworzyłeś już {count} zadań!", "Gratulacje", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void DeleteTask_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.DataContext is TaskItem task)
            {
                if (MessageBox.Show($"Czy na pewno ukończyłeś ten task:\n\n{task.Title}?",
                                    "Potwierdzenie ukończenia",
                                    MessageBoxButton.YesNo,
                                    MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    Tasks.Remove(task);
                    SaveTasks();

                    _deletedCount++;
                    if (_deletedCount == 5 || _deletedCount == 10 || _deletedCount == 15)
                    {
                        MessageBox.Show($"🏅 Brawo! Ukończyłeś już {_deletedCount} tasków! Zdobywasz odznakę!",
                                        "Odznaka",
                                        MessageBoxButton.OK,
                                        MessageBoxImage.Information);
                    }
                }
            }
        }

        private void TaskListPanel_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (TaskListPanel.SelectedItem is TaskItem selectedTask)
            {
                MessageBox.Show($"📌 {selectedTask.Title}\n\n{selectedTask.Description}",
                                "Szczegóły zadania",
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);
            }
        }

        private void SaveTasks()
        {
            try
            {
                var json = JsonConvert.SerializeObject(Tasks, Newtonsoft.Json.Formatting.Indented);
                File.WriteAllText(_saveFilePath, json);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Błąd zapisu zadań: " + ex.Message);
            }
        }

        private void LoadTasks()
        {
            if (!File.Exists(_saveFilePath)) return;

            try
            {
                var json = File.ReadAllText(_saveFilePath);
                var loadedTasks = JsonConvert.DeserializeObject<ObservableCollection<TaskItem>>(json);

                if (loadedTasks != null)
                {
                    foreach (var t in loadedTasks)
                        t.UpdateColor();

                    Tasks.Clear();
                    foreach (var t in loadedTasks)
                        Tasks.Add(t);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Błąd odczytu zadań: " + ex.Message);
            }
        }
    }

    public class TaskItem
    {
        public string Title { get; set; }
        public DateTime Date { get; set; }
        public string Description { get; set; }
        public string ColorName { get; set; }

        [System.Text.Json.Serialization.JsonIgnore]
        public SolidColorBrush Color { get; set; }

        public void UpdateColor()
        {
            try
            {
                Color = new SolidColorBrush((Color)ColorConverter.ConvertFromString(ColorName));
            }
            catch
            {
                Color = Brushes.LightGray;
            }
        }
    }
}
