﻿using System.Windows;
using System.Windows.Controls;

namespace WpfApp1
{
    /// <summary>
    /// Logika interakcji dla klasy Rejestracja.xaml
    /// </summary>
    public partial class Rejestracja : Page
    {
        private Frame _mainFrame;
        public Rejestracja(Frame mainFrame)
        {
            InitializeComponent();
            _mainFrame = mainFrame;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(LoginTextBox.Text) ||
      string.IsNullOrWhiteSpace(PasswordBox.Password) ||
      string.IsNullOrWhiteSpace(PasswordBoxCheck.Password))
            {
                MessageBox.Show("Proszę wypełnić wszystkie pola.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (!string.Equals(PasswordBox.Password, PasswordBoxCheck.Password))
            {
                MessageBox.Show("Hasła nie są takie same", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Jeśli doszliśmy tutaj, wszystko jest ok
            MessageBox.Show("Rejestracja zakończona sukcesem!", "Sukces", MessageBoxButton.OK, MessageBoxImage.Information);
            _mainFrame.Navigate(new Logowanie(_mainFrame));
        }

        private void Zaloguj_Click(object sender, RoutedEventArgs e)
        {
            _mainFrame.Navigate(new Logowanie(_mainFrame));
        }
    }
}
