﻿using System.Windows;
using System.Windows.Controls;

namespace WpfApp1
{
    /// <summary>
    /// Logika interakcji dla klasy logowanie.xaml
    /// </summary>
    public partial class Logowanie : Page
    {
        private Frame _mainFrame;
        public Logowanie(Frame mainFrame)
        {
            InitializeComponent();
            _mainFrame = mainFrame;
        }

        private void Zaloguj_Click(object sender, RoutedEventArgs e)
        {
            if(string.IsNullOrWhiteSpace(LoginTextBox.Text) || string.IsNullOrWhiteSpace(PasswordBox.Password))
            {
                MessageBox.Show("Proszę wypełnić wszystkie pola.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            else { MessageBox.Show("Zalogowano pomyślnie"); _mainFrame.Navigate(new MenagerTask(_mainFrame)); }
                
           
        }

        private void Zarejestruj_Click(object sender, RoutedEventArgs e)
        {
            _mainFrame.Navigate(new Rejestracja(_mainFrame));
        }
    }
}
