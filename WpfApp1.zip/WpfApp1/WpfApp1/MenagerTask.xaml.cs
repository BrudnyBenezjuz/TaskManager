﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    public partial class MenagerTask : Page
    {
        private Frame _mainFrame;
        public MenagerTask(Frame mainFrame)
        {
            InitializeComponent();
            _mainFrame = mainFrame;
        }
        private void Settings_Click(object sender, RoutedEventArgs e) 
        {
            _mainFrame.Navigate(new Settings(_mainFrame));
        }
        private void Login_Click(object sender, RoutedEventArgs e) 
        {
            _mainFrame.Navigate(new Logowanie(_mainFrame));
        }
        private void AddTask_Click(object sender, RoutedEventArgs e) { /* ... */ }
        private void DeleteTask_Click(object sender, RoutedEventArgs e) { /* ... */ }
        private void EditTask_Click(object sender, RoutedEventArgs e) { /* ... */ }

    }
}
